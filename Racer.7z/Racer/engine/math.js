function DistanceSquared(x1, y1, x2, y2){
	var dX = x2 - x1;
	var dY = y2 - y1;

	return dX*dX + dY*dY;
}